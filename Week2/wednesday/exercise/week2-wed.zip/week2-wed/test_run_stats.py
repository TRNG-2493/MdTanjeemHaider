"""
test_run_stats.py -- Part C: your unit tests for run_stats.py.

Run from the starter_code folder:
    python -m unittest -v test_run_stats

Requirements (see README, Part C):
  * at least 12 test methods
  * one regression test for each of the 7 bugs (a test that FAILS on the buggy file and PASSES once fixed)
  * at least 3 tests of bad or unusual input (empty list, n == 0, missing key)
  * at least 1 test that uses assertRaises
  * at least 1 use of setUp (so tests stay independent) and at least 1 use of assertLogs (Part B)
Name every test for the behaviour it protects, e.g. test_even_count_averages_two_middle_values.
"""
import unittest

import run_stats


class TestMedian(unittest.TestCase):
    # Worked example: Arrange, Act, Assert.
    def test_odd_count_returns_middle(self):
        values = [5, 1, 3]                       # Arrange
        result = run_stats.median(values)        # Act
        self.assertEqual(result, 3)              # Assert

    # TODO: even count (BUG-1)    TODO: empty list (BUG-7)    TODO: input list not changed

    def test_even_count_returns_average_of_two_middle_values(self):
        values = [6, 1, 4, 2] # Arrange
        result = run_stats.median(values) # Act
        self.assertEqual(result, 3) # Assert

    def test_empty_list_raises_value_error(self):
        with self.assertRaises(ValueError):
            run_stats.median([])

    def test_input_list_not_changed(self):
        values = [6, 1, 4, 2] # Arrange
        new_values = run_stats.median(values) # Act
        self.assertEqual(values, [6, 1, 4, 2]) # Assert
    
class TestSlowest(unittest.TestCase):
    # TODO: n items, biggest first (BUG-2)    TODO: n == 0    TODO: caller's list not reordered (BUG-6)
    def test_n_items_biggest_first(self):
        items = [645, 342, 12, 546, 11]
        result = run_stats.slowest(items, 3) # Act
        self.assertEqual(result, [645, 546, 342]) # Assert

    def test_n_zero_raises_value_error(self):
        items = [645, 342, 12, 546, 11]
        result = run_stats.slowest(items, 0) # Act
        self.assertEqual(result, []) # Assert

    def test_callers_list_not_reordered(self):
        items = [645, 342, 12, 546, 11]
        run_stats.slowest(items, 3) # Act
        self.assertEqual(items, [645, 342, 12, 546, 11]) # Assert


class TestGroupBySuite(unittest.TestCase):
    # TODO: counts per suite and status (BUG-3)    TODO: missing "suite" -> "unknown"    TODO: assertLogs WARNING
    def test_counts_per_suite_and_status(self):
        data = [
            {"test": "t1", "suite": "login", "status": "pass"},
            {"test": "t2", "suite": "login", "status": "fail"},
            {"test": "t3", "suite": "search", "status": "pass"},
            {"test": "t4", "suite": "search", "status": "fail"},
        ]
        expected = {
            "login": {"pass": 1, "fail": 1},
            "search": {"pass": 1, "fail": 1}
        }
        result = run_stats.group_by_suite(data) # Act
        self.assertEqual(result, expected) # Assert

    def test_missing_suite_defaults_to_unknown(self):
        data = [
            {"test": "t1", "status": "pass"},
            {"test": "t2", "suite": "login", "status": "fail"},
            {"test": "t3", "suite": "search", "status": "fail"},
            {"test": "t4", "status": "fail"}
        ]
        expected = {
            "unknown": {"pass": 1, "fail": 1},
            "login": {"fail": 1},
            "search": {"fail": 1}
        }
        result = run_stats.group_by_suite(data) # Act
        self.assertEqual(result, expected) # Assert

    def test_assert_logs_warning(self):
        data = [
            {"test": "t1", "status": "pass"},
            {"test": "t2", "suite": "login", "status": "fail"},
            {"test": "t3", "suite": "search", "status": "fail"},
            {"test": "t4", "status": "fail"}
        ]
        with self.assertLogs(level="WARNING") as log:
            run_stats.group_by_suite(data) # Act
        self.assertTrue(any("WARNING" in message for message in log.output)) # Assert


class TestNoteFlaky(unittest.TestCase):
    # TODO: two calls without a list do not share state (BUG-4)    TODO: caller's own list is extended
    def test_two_calls_without_list_do_not_share_state(self):
        first_call = run_stats.note_flaky("t1")
        second_call = run_stats.note_flaky("t2")
        self.assertNotEqual(first_call, second_call)

    def test_callers_list_is_extended(self):
        callers_list = ["t0"]
        run_stats.note_flaky("t1", callers_list)
        self.assertIn("t1", callers_list)


class TestRunIdAndSummary(unittest.TestCase):
    def setUp(self):
        run_stats.run_counter = 0                # reset shared state so each test starts clean
        self.results = [{"test": "t1", "suite": "login", "status": "pass"}]

    # TODO: ids increase (BUG-5)    TODO: summary with durations (latest_ms, BUG-6)    TODO: summary with [] (BUG-7)
    def test_ids_increase(self):
        first_id = run_stats.next_run_id()
        second_id = run_stats.next_run_id()
        self.assertLess(first_id, second_id)

    def test_summary_with_durations(self):
        durations = [100, 120, 50, 600, 20, 10]
        summary = run_stats.summarise_run(self.results, durations)
        self.assertEqual(summary["latest_ms"], 10)

    def test_summary_with_empty_durations(self):
        summary = run_stats.summarise_run(self.results, [])
        self.assertIsNone(summary["median_ms"])
        self.assertIsNone(summary["slowest_ms"])
        self.assertIsNone(summary["latest_ms"])




if __name__ == "__main__":
    unittest.main()
