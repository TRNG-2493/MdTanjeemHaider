# Nightly smoke run: shared team settings
PASS_THRESHOLD = 95   # percent of tests that must pass for a GREEN run
RETRIES = 1
TIMEOUT_SECONDS = 30
REPORT_FORMAT = "text"
REPORT_DIR = "out"
SUITES = ["login", "search", "checkout", "payments"]
