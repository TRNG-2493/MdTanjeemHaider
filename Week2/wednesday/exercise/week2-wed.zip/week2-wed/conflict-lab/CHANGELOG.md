# Changelog (team: QE Foundations)

## Unreleased
- Nightly smoke run reports a GREEN or RED verdict
- Strict gate: payments suite added, threshold raised (Sam)
