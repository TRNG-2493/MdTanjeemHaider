"""Print the verdict for the nightly smoke run."""
from settings import PASS_THRESHOLD, SUITES


def verdict(rate):
    return "GREEN" if rate >= PASS_THRESHOLD else "RED"


def summary_line(passed, total):
    """One line for the morning email, e.g. "3/4 passed (75.0%)"."""
    return f"{passed}/{total} passed ({passed / total * 100:.1f}%)"


def failing_suites(results):
    """Names of suites that have at least one failed test, sorted."""
    return sorted({r["suite"] for r in results if r["status"] == "fail"})


def main():
    print("Suites:", ", ".join(SUITES))
    print("Verdict for 93.0%:", verdict(93.0))


if __name__ == "__main__":
    main()
