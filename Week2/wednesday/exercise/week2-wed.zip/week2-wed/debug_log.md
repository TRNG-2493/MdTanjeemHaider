# Debug log (Part A)

Name: Md Tanjeem Haider   Date: Oct 24, 2026

Fill one block per ticket, in the order you fixed them. Use the method from the lesson: Reproduce, Read,
Isolate, Hypothesise, Test, Fix, Verify. Short answers are fine, but the EVIDENCE line must be something
you actually saw (a pdb command and its output, or a print line).

## BUG-1

- Symptom (what I saw): BUG-1 (BUG-1: median of an even-sized list): 3
- Family (syntax / runtime / logic): Logic
- Hypothesis (before I looked): returning mean instead of median
- Evidence (pdb command + output, or print output):```
  (Pdb) values
  [4, 1, 3, 2]
  (Pdb) ordered
  [1, 2, 3, 4]```
- Root cause (one sentence): returns only ordered[mid], never averaging ordered[mid-1] and ordered[mid] for even count
- Fix (one sentence): Add an if block to return the number between the 2 middle elements in a list with even number of elements
- Verified by:
  ```
  python run_report.py 1
  BUG-1: BUG-1: median of an even-sized list
  2.5
  ```

## BUG-2

- Symptom (what I saw):
  ```
  BUG-2: BUG-2: top 3 slowest tests
  [340, 210]
  ```
- Family (syntax / runtime / logic): logic
- Hypothesis (before I looked): The function might be slicing incorrectly and not including the nth element.
- Evidence (pdb command + output, or print output):```
  (Pdb) durations
  [340, 210, 150, 120, 95, 80]
  (Pdb) durations[:n]
  [340, 210, 150]```
- Root cause (one sentence):  slicing the list with end=n-1 instead of n which makes it return only 2 elements
- Fix (one sentence): change `durations[:n - 1]` to `durations[:n]`
- Verified by:
  ```
  python run_report.py 2
  BUG-2: BUG-2: top 3 slowest tests
  [340, 210, 150]
  ```

## BUG-3

- Symptom (what I saw):
  ```Shell
  BUG-3: BUG-3: counting outcomes per suite
  Traceback (most recent call last):
    File "E:\week2-wed\run_report.py", line 84, in <module>
      main(sys.argv)
      ~~~~^^^^^^^^^^
    File "E:\week2-wed\run_report.py", line 74, in main
      print(TICKETS[number]())          # a crash shows the full traceback on purpose
            ~~~~~~~~~~~~~~~^^
    File "E:\week2-wed\run_report.py", line 37, in ticket_3
      return run_stats.group_by_suite(RESULTS)
             ~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^
    File "E:week2-wed\run_stats.py", line 66, in group_by_suite
      grouped[result["suite"]][result["status"]] += 1
      ~~~~~~~^^^^^^^^^^^^^^^^^
  KeyError: 'login'
  ```
- Family (syntax / runtime / logic): runtime
- Hypothesis (before I looked): The key `'login'` doesn't exist in `grouped` and such case is not safely handled
- Evidence (pdb command + output, or print output):```
  (Pdb) p grouped
  {}
  (Pdb) p result
  {'test': 't1', 'suite': 'login', 'status': 'pass'}```
- Root cause (one sentence): `grouped` contains no keys
- Fix (one sentence): create the `suite` dict and `status` counter if they do not exist
- Verified by:
  ```
  python run_report.py 3
  BUG-3: BUG-3: counting outcomes per suite
  {'login': {'pass': 2, 'fail': 1}, 'search': {'pass': 1}}
  ```

## BUG-4

- Symptom (what I saw):
  ```
  BUG-4: BUG-4: two separate reports each keep a flaky list
  (['t2', 't9'], ['t2', 't9'])
  ```
- Family (syntax / runtime / logic): logic
- Hypothesis (before I looked): The same list is being used for all function calls
- Evidence (pdb command + output, or print output):```
  E:\week2-wed>python run_report.py 4
  BUG-4: BUG-4: two separate reports each keep a flaky list
  > e:\week2-wed\run_stats.py(82)note_flaky()
  -> breakpoint()
  (Pdb) p flaky
  []
  (Pdb) p test_name
  't2'
  (Pdb) c
  > e:\week2-wed\run_stats.py(82)note_flaky()
  -> breakpoint()
  (Pdb) p test_name
  't9'
  (Pdb) p flaky  
  ['t2']```
- Root cause (one sentence): The default `flaky=[]` is evaluated once at function definition time, so every call that omits flaky appends to the same shared list instead of getting a new one.
- Fix (one sentence): default flaky to None and create a new list if caller passes no list
- Verified by:
  ```
  python run_report.py 4
  BUG-4: BUG-4: two separate reports each keep a flaky list
  (['t2'], ['t9'])
  ```

## BUG-5

- Symptom (what I saw):
  ```Shell
  Traceback (most recent call last):
    File "E:\week2-wed\run_report.py", line 84, in <module>
      main(sys.argv)
      ~~~~^^^^^^^^^^
    File "E:\week2-wed\run_report.py", line 74, in main
      print(TICKETS[number]())          # a crash shows the full traceback on purpose
            ~~~~~~~~~~~~~~~^^
    File "E:\week2-wed\run_report.py", line 49, in ticket_5
      return run_stats.next_run_id()
             ~~~~~~~~~~~~~~~~~~~~~^^
    File "E:\week2-wed\run_stats.py", line 26, in next_run_id
      run_counter += 1
      ^^^^^^^^^^^
  UnboundLocalError: cannot access local variable 'run_counter' where it is not associated with a value
  ```
- Family (syntax / runtime / logic): runtime
- Hypothesis (before I looked): trying to increment a non existant counter
- Evidence (pdb command + output, or print output):```
  (Pdb) p run_counter
  0
  (Pdb) p locals()
  {}```
- Root cause (one sentence): `run_counter` does not exist locally
- Fix (one sentence): Create a global declaration for run_counter inside the function
- Verified by:
  ```
  python run_report.py 5   
  BUG-5: BUG-5: the id for the first report
  RUN-0001
  ```

## BUG-6

- Symptom (what I saw):
  ```
  BUG-6: BUG-6: the dashboard summary, 'latest' test duration
  {'run_id': 'RUN-0001', 'total': 4, 'by_suite': {'login': {'pass': 2, 'fail': 1}, 'search': {'pass': 1}}, 'median_ms': 135.0, 'slowest_ms': [340, 210, 150], 'latest_ms': 80}
  ```
- Family (syntax / runtime / logic): logic
- Hypothesis (before I looked): the 'latest_ms' key in the summary is not correctly reflecting the last test duration
- Evidence (pdb command + output, or print output):
  ```
  > e:\week2-wed\run_stats.py(99)summarise_run()
  -> breakpoint()
  (Pdb) p durations
  [120, 80, 340, 95, 210, 150]
  (Pdb) n
  > e:\week2-wed\run_stats.py(101)summarise_run()
  -> "run_id": next_run_id(),
  (Pdb) n
  > e:\week2-wed\run_stats.py(102)summarise_run()
  -> "total": len(results),
  (Pdb) n
  > e:\week2-wed\run_stats.py(103)summarise_run()
  -> "by_suite": group_by_suite(results),
  (Pdb) n
  > e:\week2-wed\run_stats.py(104)summarise_run()
  -> "median_ms": median(durations),
  (Pdb) p durations
  [120, 80, 340, 95, 210, 150]
  (Pdb) n
  > e:\week2-wed\run_stats.py(105)summarise_run()
  -> "slowest_ms": slowest(durations, 3),
  (Pdb) p durations
  [120, 80, 340, 95, 210, 150]
  (Pdb) n
  > e:\week2-wed\run_stats.py(106)summarise_run()
  -> "latest_ms": durations[-1],
  (Pdb) p durations
  [340, 210, 150, 120, 95, 80]
  ```
- Root cause (one sentence): the `slowest()` function is changing the caller's list by sorting without making a copy
- Fix (one sentence): instead of using `.sort(reversed=True)` use `sorted()` to get a copy of the caller's list
- Verified by:
  ```
  python run_report.py 6
  BUG-6: BUG-6: the dashboard summary, 'latest' test duration
  {'run_id': 'RUN-0001', 'total': 4, 'by_suite': {'login': {'pass': 2, 'fail': 1}, 'search': {'pass': 1}}, 'median_ms': 135.0, 'slowest_ms': [340, 210, 150], 'latest_ms': 150}
  ```

## BUG-7

- Symptom (what I saw):
  ```Shell
  E:\workmaxxing\week2-wed>python run_report.py 7
  BUG-7: BUG-7: a night where no tests produced a timing
  Traceback (most recent call last):
    File "E:\workmaxxing\week2-wed\run_report.py", line 84, in <module>
      main(sys.argv)
      ~~~~^^^^^^^^^^
    File "E:\workmaxxing\week2-wed\run_report.py", line 74, in main
      print(TICKETS[number]())          # a crash shows the full traceback on purpose
            ~~~~~~~~~~~~~~~^^
    File "E:\workmaxxing\week2-wed\run_report.py", line 61, in ticket_7
      return run_stats.summarise_run(RESULTS, [])
             ~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^
    File "E:\workmaxxing\week2-wed\run_stats.py", line 103, in summarise_run
      "median_ms": median(durations),
                   ~~~~~~^^^^^^^^^^^
    File "E:\workmaxxing\week2-wed\run_stats.py", line 40, in median
      return (ordered[mid_left] + ordered[mid_right]) / 2
              ~~~~~~~^^^^^^^^^^
  IndexError: list index out of range
  ```
- Family (syntax / runtime / logic): runtime
- Hypothesis (before I looked): `median()` not handling the case where durations list is empty or has only 1 element
- Evidence (pdb command + output, or print output): ``(Pdb) p values []``
- Root cause (one sentence): `median()` does not handle empty lists
- Fix (one sentence): raise a ValueError when the function is given an empty list
- Verified by:
  ```
  python run_report.py 7
  BUG-7: BUG-7: a night where no tests produced a timing
  {'run_id': 'RUN-0001', 'total': 4, 'by_suite': {'login': {'pass': 2, 'fail': 1}, 'search': {'pass': 1}}, 'median_ms': None, 'slowest_ms': [], 'latest_ms': None}
  ```

## Reflection (3 sentences)
Ticket 6 was the hardest because the output did not look wrong at first glance. The breakpoint helped the most because it stops the code exactly where I need it, so I do not have to spam `c` and `n`. Next time I will check values before and after each function call, and read the docstrings first so I know what the function should actually do.
