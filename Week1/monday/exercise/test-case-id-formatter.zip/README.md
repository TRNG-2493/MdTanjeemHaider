# What the tool does
It asks for test-case details, formats an ID, and prints the test results summary, including the pass rate and release-readiness status.

# How to run it
```python test_case_id_formatter.py```

# Example Output
```
=== Test-Case ID Formatter ===
Module prefix (e.g. login): login
Test number: 42
Test title: Testing Run
Tests executed: 40
Tests passed: 36
Generated ID: LOGIN-0042
Title: Testing Run
Failed: 4
Pass rate: 90.0%
Release ready: True
```